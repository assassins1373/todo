"""main.py - برنامهٔ To-Do List Pro با رابط گرافیکی چندفرمی"""
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime, date
from models import Task, ToDoList
from utils import emrooz, gozaresh, hoshdar

FAYL = "data.txt"
OLAVIAT_HA = ["زیاد", "متوسط", "کم"]


class Barname(tk.Tk):
    """فرم اصلی: ساعت، لیست کارها و دکمه‌ها"""
    def __init__(self):
        super().__init__()
        self.title("To-Do List Pro")
        self.todo = ToDoList()
        self.todo.load_from_file(FAYL)
        self.saat = tk.Label(self, font=("Tahoma", 12))
        self.saat.pack(pady=5)
        self.list_box = tk.Listbox(self, width=75, height=15, font=("Tahoma", 10), justify="right")
        self.list_box.pack(padx=10)
        bar = tk.Frame(self)
        bar.pack(pady=8)
        dokme_ha = [("امروز", self.namayesh_emrooz), ("همه", self.namayesh_hame),
                   ("افزودن", lambda: FormAfzoodan(self)), ("حذف", self.hazf),
                   ("انجام شد", self.anjam), ("فیلتر", lambda: FormFilter(self)),
                   ("گزارش", lambda: FormGozaresh(self)), ("ذخیره", self.zakhire)]
        for text, cmd in dokme_ha:
            tk.Button(bar, text=text, width=8, command=cmd).pack(side="right", padx=2)
        self.namayesh_emrooz()
        self.tik_tak()
        self.after(500, self.barresi_aghab)

    def tik_tak(self):
        """نمایش زندهٔ تاریخ و ساعت سیستم"""
        self.saat.config(text=datetime.now().strftime("%Y-%m-%d   %H:%M:%S"))
        self.after(1000, self.tik_tak)

    def namayesh(self, tasks):
        """نمایش کارها در لیست؛ کارهای عقب‌افتاده قرمز"""
        self.namayeshi = tasks
        self.list_box.delete(0, "end")
        for t in tasks:
            self.list_box.insert("end", f"{t} | موعد: {t.due_date}")
            if not t.is_done and t.due_date < emrooz():
                self.list_box.itemconfig("end", fg="red")

    def namayesh_hame(self):
        self.namayesh(self.todo.list_tasks())

    def namayesh_emrooz(self):
        self.namayesh(self.todo.list_by_date(emrooz()))

    def entekhabi(self):
        sel = self.list_box.curselection()
        return self.namayeshi[sel[0]] if sel else None

    def hazf(self):
        t = self.entekhabi()
        if t:
            self.todo.remove_task(t.title)
            self.zakhire(False)
            self.namayesh_hame()

    def anjam(self):
        t = self.entekhabi()
        if t:
            t.is_done = not t.is_done
            self.zakhire(False)
            self.namayesh_hame()

    def zakhire(self, payam=True):
        self.todo.save_to_file(FAYL)
        if payam:
            messagebox.showinfo("ذخیره", "اطلاعات ذخیره شد")

    def barresi_aghab(self):
        """هشدار برای کارهای ناتمامی که موعدشان گذشته"""
        aghab = [t.title for t in self.todo.tasks if not t.is_done and t.due_date < emrooz()]
        if aghab:
            hoshdar("کارهای عقب‌افتاده:\n" + "\n".join(aghab))


class Form(tk.Toplevel):
    """کلاس پایهٔ فرم‌های فرعی"""
    def __init__(self, app, title):
        super().__init__(app)
        self.app = app
        self.title(title)

    def khane(self, label, value=""):
        tk.Label(self, text=label).pack()
        e = tk.Entry(self, justify="right")
        e.insert(0, value)
        e.pack(padx=30)
        return e

    def kashoyi(self, label, values):
        tk.Label(self, text=label).pack()
        c = ttk.Combobox(self, values=values, state="readonly")
        c.current(0)
        c.pack()
        return c

    def dokme(self, text, cmd):
        tk.Button(self, text=text, width=12, command=cmd).pack(pady=10)


class FormAfzoodan(Form):
    """فرم افزودن کار جدید"""
    def __init__(self, app):
        super().__init__(app, "افزودن کار")
        self.t = self.khane("عنوان:")
        self.p = self.kashoyi("اولویت:", OLAVIAT_HA)
        self.d = self.khane("تاریخ هدف (YYYY-MM-DD):", emrooz())
        self.dokme("ثبت", self.afzoodan)

    def afzoodan(self):
        try:
            date.fromisoformat(self.d.get())
        except ValueError:
            return messagebox.showerror("خطا", "تاریخ نامعتبر است", parent=self)
        if not self.t.get().strip():
            return messagebox.showerror("خطا", "عنوان را وارد کنید", parent=self)
        self.app.todo.add_task(Task(self.t.get(), self.p.get(), self.d.get()))
        self.app.zakhire(False)
        self.app.namayesh_hame()
        self.destroy()


class FormFilter(Form):
    """فرم جستجو و فیلتر بر اساس تاریخ و اولویت"""
    def __init__(self, app):
        super().__init__(app, "فیلتر")
        self.d = self.khane("تاریخ (خالی = همه):")
        self.p = self.kashoyi("اولویت:", ["همه"] + OLAVIAT_HA)
        self.dokme("فیلتر", self.ejra)

    def ejra(self):
        d, p = self.d.get(), self.p.get()
        self.app.namayesh([t for t in self.app.todo.tasks
                       if (not d or t.due_date == d) and (p == "همه" or t.priority == p)])


class FormGozaresh(Form):
    """فرم گزارش‌گیری از یک بازهٔ زمانی"""
    def __init__(self, app):
        super().__init__(app, "گزارش")
        self.start = self.khane("از تاریخ:", emrooz())
        self.end = self.khane("تا تاریخ:", emrooz())
        self.dokme("ساخت گزارش", self.ejra)

    def ejra(self):
        name = f"report_{self.start.get()}.txt"
        gozaresh(self.app.todo.tasks, self.start.get(), self.end.get(), name)
        messagebox.showinfo("گزارش", f"گزارش در فایل {name} ذخیره شد", parent=self)


Barname().mainloop()
