"""utils.py - توابع کمکی: تاریخ امروز، گزارش و نوتیفیکیشن"""
from datetime import date
from tkinter import messagebox


def emrooz():
    return str(date.today())


def gozaresh(tasks, start, end, filename):
    """گزارش کارهای بازهٔ start تا end را در فایل می‌نویسد"""
    with open(filename, "w", encoding="utf-8") as f:
        for d in sorted({t.due_date for t in tasks if start <= t.due_date <= end}):
            f.write(f"تاریخ: {d}\n" + "-" * 21 + "\n")
            for t in tasks:
                if t.due_date == d:
                    f.write(f"{t}\n")
            f.write("\n")


def hoshdar(payam):
    """نوتیفیکیشن با plyer (اگر نصب باشد) و messagebox"""
    try:
        from plyer import notification
        notification.notify(title="To-Do List Pro", message=payam)
    except Exception:
        pass
    messagebox.showwarning("هشدار", payam)
