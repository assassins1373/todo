"""models.py - کلاس‌های Task و ToDoList"""
from datetime import datetime


class Task:
    """یک کار: عنوان، وضعیت، اولویت، تاریخ ایجاد و تاریخ هدف"""
    def __init__(self, title, priority, due_date, is_done=False, created_date=None):
        self.title = title
        self.priority = priority
        self.due_date = due_date
        self.is_done = is_done
        self.created_date = created_date or datetime.now().strftime("%Y-%m-%d %H:%M")

    def __str__(self):
        vaziat = "انجام‌شده" if self.is_done else "ناتمام"
        return f"- عنوان: {self.title} | وضعیت: {vaziat} | اولویت: {self.priority}"


class ToDoList:
    """مدیریت لیست کارها"""
    def __init__(self):
        self.tasks = []

    def add_task(self, task):
        self.tasks.append(task)

    def remove_task(self, title):
        self.tasks = [t for t in self.tasks if t.title != title]

    def list_tasks(self):
        return self.tasks

    def list_by_date(self, date):
        return [t for t in self.tasks if t.due_date == date]

    def save_to_file(self, filename):
        with open(filename, "w", encoding="utf-8") as f:
            for t in self.tasks:
                f.write(f"{t.title}|{t.is_done}|{t.priority}|{t.created_date}|{t.due_date}\n")

    def load_from_file(self, filename):
        try:
            with open(filename, encoding="utf-8") as f:
                for line in f:
                    title, done, priority, created, due = line.strip().split("|")
                    self.tasks.append(Task(title, priority, due, done == "True", created))
        except FileNotFoundError:
            pass
